import 'package:flutter/material.dart';

void main() => runApp(const MyFutureApp());

const Color brand = Color(0xFF5B45D6);
const Color pale = Color(0xFFF4F1FF);

class MyFutureApp extends StatelessWidget {
  const MyFutureApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'my future',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brand),
        scaffoldBackgroundColor: const Color(0xFFF8F7FC),
        appBarTheme: const AppBarTheme(
          backgroundColor: brand,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  int hskDone = 0;
  int mathDone = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        onHSK: () => setState(() => index = 1),
        onMath: () => setState(() => index = 2),
        hskDone: hskDone,
        mathDone: mathDone,
      ),
      HskPage(onCompleted: () => setState(() => hskDone++)),
      MathPage(onCompleted: () => setState(() => mathDone++)),
      ProgressPage(hskDone: hskDone, mathDone: mathDone),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('my future', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'ပင်မ'),
          NavigationDestination(icon: Icon(Icons.translate_rounded), label: 'HSK'),
          NavigationDestination(icon: Icon(Icons.calculate_rounded), label: 'သင်္ချာ'),
          NavigationDestination(icon: Icon(Icons.insights_rounded), label: 'တိုးတက်မှု'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onHSK;
  final VoidCallback onMath;
  final int hskDone;
  final int mathDone;
  const HomePage({
    super.key, required this.onHSK, required this.onMath,
    required this.hskDone, required this.mathDone,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF6B56E8), Color(0xFFAB69E8)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.auto_stories_rounded, color: Colors.white, size: 42),
              SizedBox(height: 12),
              Text('Learn Today,', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
              Text('Build Your Tomorrow!', style: TextStyle(color: Colors.white, fontSize: 18)),
              SizedBox(height: 8),
              Text('နေ့တိုင်း နည်းနည်းစီလေ့လာပြီး မိမိအနာဂတ်ကို တည်ဆောက်ပါ။', style: TextStyle(color: Colors.white, fontSize: 15)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Text('ဒီနေ့ ဘာလေ့လာမလဲ?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        FeatureCard(
          icon: Icons.translate_rounded, color: const Color(0xFFE9E2FF),
          title: 'HSK Chinese', subtitle: 'HSK 1–9 · တရုတ်စာနှင့် မြန်မာအဓိပ္ပာယ်',
          onTap: onHSK,
        ),
        FeatureCard(
          icon: Icons.calculate_rounded, color: const Color(0xFFDDF8E8),
          title: 'သင်္ချာလေ့လာမယ်', subtitle: 'အခြေခံတွက်ချက်မှုနှင့် အက္ခရာသင်္ချာ',
          onTap: onMath,
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: StatCard(label: 'HSK ပြီးမြောက်မှု', value: '$hskDone', icon: Icons.menu_book_rounded)),
          const SizedBox(width: 12),
          Expanded(child: StatCard(label: 'သင်္ချာအဖြေ', value: '$mathDone', icon: Icons.check_circle_outline)),
        ]),
        const SizedBox(height: 12),
        const Text('မှတ်ချက် - လက်ရှိဗားရှင်းတွင် နမူနာသင်ခန်းစာများ ပါဝင်သည်။ HSK 1–9 သင်ခန်းစာအပြည့်အစုံကို နောက်ထပ်ထည့်နိုင်သည်။', style: TextStyle(color: Colors.black54, height: 1.5)),
      ],
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const FeatureCard({super.key, required this.icon, required this.color, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      leading: CircleAvatar(backgroundColor: color, child: Icon(icon, color: brand)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(subtitle)),
      trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 17),
      onTap: onTap,
    ),
  );
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: brand),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.black54)),
      ]),
    ),
  );
}

class HskWord {
  final String hanzi, pinyin, burmese;
  const HskWord(this.hanzi, this.pinyin, this.burmese);
}

const List<HskWord> sampleWords = [
  HskWord('你好', 'nǐ hǎo', 'မင်္ဂလာပါ'),
  HskWord('谢谢', 'xiè xie', 'ကျေးဇူးတင်ပါတယ်'),
  HskWord('再见', 'zài jiàn', 'ပြန်တွေ့မယ် / နှုတ်ဆက်ပါတယ်'),
  HskWord('老师', 'lǎo shī', 'ဆရာ / ဆရာမ'),
  HskWord('学生', 'xué sheng', 'ကျောင်းသား / ကျောင်းသူ'),
  HskWord('朋友', 'péng you', 'သူငယ်ချင်း'),
  HskWord('水', 'shuǐ', 'ရေ'),
  HskWord('中国', 'Zhōng guó', 'တရုတ်နိုင်ငံ'),
];

class HskPage extends StatefulWidget {
  final VoidCallback onCompleted;
  const HskPage({super.key, required this.onCompleted});
  @override
  State<HskPage> createState() => _HskPageState();
}

class _HskPageState extends State<HskPage> {
  int level = 1;
  final Set<int> learned = {};

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('HSK အဆင့်ရွေးပါ', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: List.generate(9, (i) {
        final n = i + 1;
        return ChoiceChip(label: Text('HSK $n'), selected: level == n, onSelected: (_) => setState(() => level = n));
      })),
      const SizedBox(height: 14),
      Text('HSK $level · နမူနာဝေါဟာရ', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      if (level != 1)
        const Card(child: Padding(
          padding: EdgeInsets.all(14),
          child: Text('ဒီအဆင့်အတွက် နမူနာစာရင်းကို နောက်ထပ်ဖြည့်ရန် လိုအပ်သည်။ လက်ရှိတွင် HSK 1 အခြေခံဝေါဟာရကို ပြသထားနိုင်သည်။'),
        )),
      ...sampleWords.asMap().entries.map((entry) {
        final i = entry.key;
        final word = entry.value;
        return Card(
          child: ListTile(
            title: Text(word.hanzi, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            subtitle: Text('${word.pinyin}\n${word.burmese}'),
            isThreeLine: true,
            trailing: IconButton(
              tooltip: learned.contains(i) ? 'လေ့လာပြီး' : 'လေ့လာပြီးဟု မှတ်မယ်',
              icon: Icon(learned.contains(i) ? Icons.check_circle : Icons.radio_button_unchecked, color: brand),
              onPressed: () {
                setState(() {
                  if (learned.add(i)) widget.onCompleted();
                });
              },
            ),
          ),
        );
      }),
    ],
  );
}

class MathQuestion {
  final String question;
  final List<String> options;
  final int correct;
  final String explanation;
  const MathQuestion(this.question, this.options, this.correct, this.explanation);
}

const mathQuestions = [
  MathQuestion('၂၅ + ၁၇ = ?', ['၃၂', '၄၂', '၄၅', '၅၂'], 1, '၂၅ + ၁၇ = ၂၅ + ၁၀ + ၇ = ၄၂ ဖြစ်သည်။'),
  MathQuestion('၉ × ၆ = ?', ['၄၂', '၅၄', '၆၃', '၅၆'], 1, '၉ ကို ၆ ကြိမ်ပေါင်းလျှင် ၅၄ ဖြစ်သည်။'),
  MathQuestion('x + 7 = 15 ဖြစ်လျှင် x = ?', ['၇', '၈', '၉', '၂၂'], 1, 'နှစ်ဖက်စလုံးမှ ၇ နုတ်ပါ။ x = ၁၅ − ၇ = ၈။'),
  MathQuestion('၁/၂ + ၁/၂ = ?', ['၁/၄', '၁/၂', '၁', '၂'], 2, 'ပိုင်းခြေတူသောကြောင့် အပေါ်ကိန်း ၁ + ၁ = ၂၊ ထို့ကြောင့် ၂/၂ = ၁။'),
  MathQuestion('စတုဂံ၏ ဧရိယာ = ?', ['အလျား + အနံ', '၂ × (အလျား + အနံ)', 'အလျား × အနံ', 'အလျား ÷ အနံ'], 2, 'စတုဂံဧရိယာ = အလျား × အနံ ဖြစ်သည်။'),
];

class MathPage extends StatefulWidget {
  final VoidCallback onCompleted;
  const MathPage({super.key, required this.onCompleted});
  @override
  State<MathPage> createState() => _MathPageState();
}

class _MathPageState extends State<MathPage> {
  int q = 0;
  int? selected;
  int score = 0;
  bool answered = false;

  void next() {
    if (!answered) return;
    if (q < mathQuestions.length - 1) {
      setState(() { q++; selected = null; answered = false; });
    } else {
      showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('လေ့ကျင့်ခန်းပြီးပါပြီ!'),
          content: Text('ရမှတ်: $score / ${mathQuestions.length}\nနောက်တစ်ကြိမ် ထပ်လေ့ကျင့်ကြည့်ပါ။'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ပိတ်မယ်'))],
        ),
      );
      setState(() { q = 0; selected = null; answered = false; score = 0; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final item = mathQuestions[q];
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('သင်္ချာ လေ့ကျင့်ခန်း', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: (q + 1) / mathQuestions.length, minHeight: 7, borderRadius: BorderRadius.circular(8)),
        const SizedBox(height: 8),
        Text('မေးခွန်း ${q + 1} / ${mathQuestions.length}    ရမှတ် $score'),
        const SizedBox(height: 16),
        Card(child: Padding(
          padding: const EdgeInsets.all(22),
          child: Text(item.question, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        )),
        const SizedBox(height: 12),
        ...item.options.asMap().entries.map((entry) {
          final i = entry.key;
          Color? tileColor;
          if (answered && i == item.correct) tileColor = Colors.green.shade100;
          if (answered && i == selected && i != item.correct) tileColor = Colors.red.shade100;
          return Card(
            color: tileColor,
            child: ListTile(
              title: Text(entry.value, style: const TextStyle(fontSize: 18)),
              trailing: selected == i ? const Icon(Icons.radio_button_checked) : const Icon(Icons.radio_button_off),
              onTap: answered ? null : () => setState(() => selected = i),
            ),
          );
        }),
        if (answered)
          Card(color: pale, child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text('${selected == item.correct ? 'မှန်ပါတယ်! 🎉' : 'မမှန်သေးပါ။'}\n${item.explanation}', style: const TextStyle(height: 1.5)),
          )),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: !answered
              ? selected == null ? null : () {
                  setState(() {
                    answered = true;
                    if (selected == item.correct) { score++; widget.onCompleted(); }
                  });
                }
              : next,
          child: Text(answered ? (q == mathQuestions.length - 1 ? 'ရလဒ်ကြည့်မယ်' : 'နောက်မေးခွန်း') : 'အဖြေစစ်မယ်'),
        ),
      ],
    );
  }
}

class ProgressPage extends StatelessWidget {
  final int hskDone;
  final int mathDone;
  const ProgressPage({super.key, required this.hskDone, required this.mathDone});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('ကျွန်ုပ်၏ တိုးတက်မှု', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      StatCard(label: 'လေ့လာပြီး HSK ဝေါဟာရ', value: '$hskDone', icon: Icons.translate),
      StatCard(label: 'မှန်ကန်သော သင်္ချာအဖြေ', value: '$mathDone', icon: Icons.calculate),
      const SizedBox(height: 12),
      const Card(child: Padding(
        padding: EdgeInsets.all(16),
        child: Text('မှတ်ချက် - လက်ရှိဗားရှင်းမှာ တိုးတက်မှုကို App ဖွင့်ထားစဉ်သာ မှတ်ထားသည်။ ဖုန်းထဲတွင် အမြဲသိမ်းထားနိုင်ရန် local database ထပ်ထည့်နိုင်သည်။', style: TextStyle(height: 1.5)),
      )),
    ],
  );
}
