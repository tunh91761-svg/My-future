# My Future — Flutter Android App

မြန်မာဘာသာဖြင့် HSK တရုတ်စာနှင့် သင်္ချာလေ့ကျင့်နိုင်ရန် အခြေခံ Flutter project ဖြစ်သည်။

## ပါဝင်သောအရာများ
- ပင်မစာမျက်နှာနှင့် HSK / သင်္ချာ / တိုးတက်မှု tabs
- HSK 1–9 အဆင့်ရွေးချယ်မှု
- HSK 1 နမူနာစကားလုံး ၈ လုံး (တရုတ်စာ၊ pinyin၊ မြန်မာအဓိပ္ပာယ်)
- ရွေးချယ်စရာပါသော သင်္ချာလေ့ကျင့်ခန်း ၅ ခု၊ အဖြေရှင်းချက်များ
- လက်ရှိ session အတွင်း တိုးတက်မှုရေတွက်ခြင်း

**အရေးကြီး:** HSK 2–9 အတွက် သင်ခန်းစာအပြည့်အစုံ မထည့်ရသေးပါ။ တိုးတက်မှုကိုလည်း အမြဲတမ်းသိမ်းဆည်းရန် database မပါသေးပါ။ ဒီ project က တည်ဆောက်ပြီး စမ်းသပ်နိုင်သော starter app ဖြစ်သည်။

## လိုအပ်ချက်များ
- Flutter SDK (stable)
- Android Studio နှင့် Android SDK
- Android Emulator သို့မဟုတ် USB debugging ဖွင့်ထားသော Android ဖုန်း

## စတင်အသုံးပြုခြင်း
Terminal / Command Prompt မှ project folder ထဲဝင်ပြီး—

```bash
flutter doctor
flutter pub get
flutter run
```

## APK တည်ဆောက်ခြင်း
```bash
flutter build apk --release
```

APK ဖိုင်ကို ဒီလမ်းကြောင်းမှာ ရမည်—

`build/app/outputs/flutter-apk/app-release.apk`

ဖုန်းထဲသို့ ကူးထည့်ပြီး install လုပ်ပါ။ Android က unknown apps install ခွင့်တောင်းလျှင် မိမိယုံကြည်ရသော ကိုယ်တိုင်တည်ဆောက်ထားသည့် APK အတွက်သာ ခွင့်ပြုပါ။

## Project အသစ်ကို Android Studio မှ ဖန်တီးရန် (လိုအပ်ပါက)
1. `flutter create my_future` ကို run ပါ။
2. ဒီ zip ထဲက `lib/main.dart`, `pubspec.yaml`, `analysis_options.yaml` ကို project အသစ်ထဲသို့ ကူးအစားထိုးပါ။
3. `flutter pub get` ပြီး `flutter run` လုပ်ပါ။

## နောက်ထပ်ထည့်သင့်သောအရာများ
- HSK 1–9 သင်ခန်းစာများကို အတည်ပြုထားသော curriculum အတိုင်း ဖြည့်သွင်းခြင်း
- အသံထွက် audio နှင့် listening exercises
- SQLite / shared_preferences ဖြင့် progress သိမ်းဆည်းခြင်း
- အဆင့်အလိုက် quiz၊ bookmark၊ search
- Burmese / Chinese font rendering ကို Android စက်များတွင် စမ်းသပ်ခြင်း
